from django.shortcuts import render,redirect
from django.contrib import messages
from .forms import Employeeform,UserCreation

def index(request):
    if request.method == 'POST':
        form = UserCreation(request.POST)
        form1 = Employeeform(request.POST)
        if form.is_valid() and form1.is_valid():
            user=form.save()
            profile= form1.save(commit=False)
            profile.user=user
            profile.save()
            messages.info(request, 'Account created successfully')
            return redirect('/')
        else:
            messages.info(request, "wrong password and username")
    else:
        form = UserCreation()
        form1 = Employeeform()
        context={'form':form,'form1':form1}
        return render(request, 'index.html',context)

def addemp(request):
    return render(request,"addemp.html")

def viewemp(request):
    return render(request,"viewemp.html")
