from django.shortcuts import render,redirect
from django.contrib import messages
from .forms import Employeeform,UserCreation
from django.contrib.auth import login,authenticate,logout
from django.contrib.auth.models import User
from django.contrib.auth.forms import AuthenticationForm

def index(request):
    if request.method == 'POST':
        form = UserCreation(request.POST)
        form1 = Employeeform(request.POST)
        if form.is_valid() and form1.is_valid():
            user=form.save()
            profile= form1.save(commit=False)
            profile.user=user
            profile.save()
            messages.info(request, 'Account created successfully')
            return redirect('/')
        else:
            messages.info(request, "wrong password and username")
    else:
        form = UserCreation()
        form1 = Employeeform()
        context={'form':form,'form1':form1}
        return render(request, 'index.html',context)


def login1(request):
        if request.method == 'POST':
            user = authenticate(request, username=request.POST.get('username'), password=request.POST.get('password'))
            if user is not None:
                if request.user.is_superuser:
                    login(request,user)
                    return redirect("/viewemp")
                elif request.user:
                    login(request, user)
                    return redirect("/emphome")
            else:
                form = AuthenticationForm()
                messages.info(request, "username and password doesn't exists ")
                return render(request, "login.html", {'form': form})
        else:
            form = AuthenticationForm()

        return render(request, "login.html", {'form': form})

def addemp(request):
    return render(request,"addemp.html")

def viewemp(request):
        s=User.objects.all()
        con={'s':s}
        return render(request,"viewemp.html",con)

def emphome(request):
    return render(request,"emphome.html")

def logout1(request):
    logout(request)
    return redirect("/")