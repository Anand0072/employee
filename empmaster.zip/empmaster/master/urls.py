from django.urls import path
from . import views

urlpatterns = [
    path('',views.login1, name="login1"),
    path('addemp',views.addemp, name="addemp"),
    path('viewemp',views.viewemp, name="viewemp"),
    path('index',views.index, name="index"),
    path('emphome',views.emphome, name="emphome"),
    path('logout1',views.logout1, name="logout1"),
    ]
